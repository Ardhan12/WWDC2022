//
//  MainViewController.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 21/04/22.
//

import UIKit

class MainViewController: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 950, height: 300)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
Long ago, there was a kingdom called Pagaruyung.\
King Pagaruyung was a wise and just leader.\
One day, news came that the Majapahit Kingdom.\
from Java would attack the Pagaruyung Kingdom.\
The troops of the Majapahit Kingdom began to arrive\
and stayed in the border area to arrange a strategy\
to seize the kingdom that was safe and secure.
"""
        return label
    }()
    
    var raja: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "raja")
        return foto
    }()
    
    var orang: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var orang2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var rumahgadang: UIImageView = {
        let rumah = UIImageView()
        rumah.frame.origin = CGPoint(x: 0, y: 50)
        rumah.frame.size = CGSize(width: 800, height: 500)
        rumah.contentMode = .scaleAspectFill
        
        rumah.image = UIImage(named: "rumah")
        return rumah
    }()
    
    var nextPage1: UIButton = {
        let next = UIButton()
        next.frame.origin = CGPoint(x: 0, y: 0)
        next.frame.size = CGSize(width: 150, height: 50)
        next.setTitle("Next Story", for: .normal)
        next.backgroundColor = .systemYellow
        next.layer.cornerRadius = 10
        
        return next
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        //Mark: label
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 400
        view.addSubview(labelWellcome)
        
        nextPage1.center = view.center
        nextPage1.frame.origin.y += 550
        nextPage1.frame.origin.x += 420
        view.addSubview(nextPage1)
        nextPage1.addTarget(self, action: #selector(actionNextPage(_:)), for: .touchUpInside)
    
        rumahgadang.center = view.center
        rumahgadang.frame.origin.y -= 360
        view.addSubview(rumahgadang)
        
        //Mark: Image
        orang.center = view.center
        orang.frame.origin.y += 20
        orang.frame.origin.x -= 150
        view.addSubview(orang)
        orang2.center = view.center
        orang2.frame.origin.y += 20
        orang2.frame.origin.x += 150
        view.addSubview(orang2)
        
        raja.center = view.center
        raja.frame.origin.y += 100
        view.addSubview(raja)
    }
    
    @objc func actionNextPage(_ sender: UIButton){
        navigationController?.pushViewController(pageOne(), animated: true)
    }
    
    @objc func actionNext(_ sender: UIButton){
        print("cliked")
        
        let alert = UIAlertController(title: "Nais you make your first move", message: "button clicked", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "Ok", style: .default, handler: {
            action in
        })
        alert.addAction(ok)
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: { action in})
        alert.addAction(cancel)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
}
