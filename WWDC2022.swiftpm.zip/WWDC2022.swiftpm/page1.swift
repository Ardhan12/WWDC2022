//
//  page1.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 22/04/22.
//

import UIKit

class pageOne: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 950, height: 300)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
Despite getting threats from Majapahit, the courtiers of the Pagaruyung kingdom were never afraid to see such conditions and thought clearly. This is done so that there is no resistance or war that can harm the people.then the Pagaruyung kingdom led by a just and wise king there took the right steps. To avoid war, it chooses to negotiate or discuss
"""
        return label
    }()
    
    var speak1: UILabel = {
        let label2 = UILabel()
        label2.frame.origin = CGPoint(x: 0, y: 0)
        label2.frame.size = CGSize(width: 250, height: 200)
        label2.layer.cornerRadius = 30
        label2.layer.masksToBounds = true
        label2.textAlignment = NSTextAlignment.center
        label2.textColor = UIColor.black
        label2.numberOfLines = 0
        label2.font = UIFont(name: "Arial", size: 14.5)
        label2.font = UIFont.systemFont(ofSize: 20)
        label2.text = """
    Your Majesty, it is better if we invite them to negotiate and ask them to leave this kingdom. If negotiation doesn't solve the problem, we challenge them to a buffalo fight!
"""
        return label2
    }()
    
    var kotak: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 350, height: 200)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kotak")
        return foto
    }()
    
    var nextPage2: UIButton = {
        let next2 = UIButton()
        next2.frame.origin = CGPoint(x: 0, y: 0)
        next2.frame.size = CGSize(width: 150, height: 50)
        next2.setTitle("Next Story", for: .normal)
        next2.backgroundColor = .systemYellow
        next2.layer.cornerRadius = 10
        
        return next2
    }()
    
    var rumahgadang: UIImageView = {
        let rumah = UIImageView()
        rumah.frame.origin = CGPoint(x: 0, y: 50)
        rumah.frame.size = CGSize(width: 800, height: 500)
        rumah.contentMode = .scaleAspectFill
        
        rumah.image = UIImage(named: "rumah2")
        return rumah
    }()
    
    var raja: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 450, height: 300)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "raja")
        return foto
    }()
    
    var pendekar: UIImageView = {
        let foto2 = UIImageView()
        foto2.frame.origin = CGPoint(x: 0, y: 0)
        foto2.frame.size = CGSize(width: 250, height: 30)
        foto2.contentMode = .scaleAspectFill
        
        foto2.image = UIImage(named: "pendekar")
        return foto2
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 400
        view.addSubview(labelWellcome)
        
        rumahgadang.center = view.center
        rumahgadang.frame.origin.y -= 390
        view.addSubview(rumahgadang)
        
        raja.center = view.center
        raja.frame.origin.x += 200
        view.addSubview(raja)
        
        pendekar.center = view.center
        pendekar.frame.origin.x -= 280
        view.addSubview(pendekar)
        
        kotak.center = view.center
        kotak.frame.origin.y -= 250
        kotak.frame.origin.x -= 110
        view.addSubview(kotak)
        
        speak1.center = view.center
        speak1.frame.origin.y -= 265
        speak1.frame.origin.x -= 110
        view.addSubview(speak1)
        
        nextPage2.center = view.center
        nextPage2.frame.origin.y += 550
        nextPage2.frame.origin.x += 420
        view.addSubview(nextPage2)
        nextPage2.addTarget(self, action: #selector(actionNextPage2(_:)), for: .touchUpInside)
    }
    
    @objc func actionNextPage2(_ sender: UIButton){
        navigationController?.pushViewController(pageTwo(), animated: true)
    }
}
