import SwiftUI

struct ContentView: View {
    var body: some View {
        //call UIKit vc
        MainVCView()
    }
}

struct MainVCView: UIViewControllerRepresentable{
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        
    }
    func makeUIViewController(context: Context) -> some UIViewController {
        //create view controller Object
        return UINavigationController(rootViewController: home())
    }
}

