//
//  page2.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 23/04/22.
//

import UIKit

class pageTwo: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 950, height: 300)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
The troops of the Majapahit Kingdom were both happy and surprised. They thought they would be welcomed by the Pagaruyung Kingdom's war troops, but they were greeted by beautiful friendly girls and delicious food.After enjoying the delicious meal, the Majapahit Kingdom troops were escorted to the palace to meet the King. King Pagaruyung greeted them warmly. Then they negotiate
"""
        return label
    }()
    
    var nextPage3: UIButton = {
        let next3 = UIButton()
        next3.frame.origin = CGPoint(x: 0, y: 0)
        next3.frame.size = CGSize(width: 150, height: 50)
        next3.setTitle("Next Story", for: .normal)
        next3.backgroundColor = .systemYellow
        next3.layer.cornerRadius = 10
        
        return next3
    }()
    
    var tenda: UIImageView = {
        let rumah = UIImageView()
        rumah.frame.origin = CGPoint(x: 0, y: 50)
        rumah.frame.size = CGSize(width: 1000, height: 400)
        rumah.contentMode = .scaleAspectFill
        
        rumah.image = UIImage(named: "tenda")
        return rumah
    }()
    
    
    var raja2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 400, height: 200)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "rajasri")
        return foto
    }()
    
    var orang: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var orang2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var wanita: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 250, height: 100)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "wanita")
        return foto
    }()
    
    var wanita2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 150, height: 1)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "wanita2")
        return foto
    }()
    
    var wanita3: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 150, height: 1)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "wanita2")
        return foto
    }()
    
    var makanan: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 150, height: 50)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "makanan")
        return foto
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 400
        view.addSubview(labelWellcome)
        
        nextPage3.center = view.center
        nextPage3.frame.origin.y += 550
        nextPage3.frame.origin.x += 420
        nextPage3.addTarget(self, action: #selector(actionButton3), for: .touchUpInside)
        view.addSubview(nextPage3)
        
        tenda.center = view.center
        tenda.frame.origin.y -= 330
        view.addSubview(tenda)
        
        orang.center = view.center
        orang.frame.origin.y -= 150
        orang.frame.origin.x -= 40
        view.addSubview(orang)
        orang2.center = view.center
        orang2.frame.origin.y -= 150
        orang2.frame.origin.x += 200
        view.addSubview(orang2)
        
        raja2.center = view.center
        raja2.frame.origin.x += 260
        view.addSubview(raja2)
        
        wanita3.center = view.center
        wanita3.frame.origin.x -= 300
        view.addSubview(wanita3)
        
        wanita2.center = view.center
        wanita2.frame.origin.x -= 350
        view.addSubview(wanita2)
        
        wanita.center = view.center
        wanita.frame.origin.x -= 150
        view.addSubview(wanita)
        
        makanan.center = view.center
        wanita.frame.origin.x -= 80
        view.addSubview(makanan)
    }
    
    @objc func actionButton3(_ sender: UIButton) {
        navigationController?.pushViewController(pageThree(), animated: true)
    }
}
