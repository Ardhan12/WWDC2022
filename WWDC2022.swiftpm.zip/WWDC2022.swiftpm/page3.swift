//
//  File.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 23/04/22.
//

import UIKit

class pageThree: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 950, height: 300)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
From the negotiations, it was agreed that they would have a buffalo fight. If in the battle the Majapahit kingdom won, then they had the right to occupy the Pagaruyung kingdom. And vice versa. If the Pagaruyung kingdom wins in the battle, then the kingdom must leave the Pagaruyung kingdom and return to their origin.
"""
        return label
    }()
    
    var speak1: UILabel = {
        let label2 = UILabel()
        label2.frame.origin = CGPoint(x: 0, y: 0)
        label2.frame.size = CGSize(width: 250, height: 200)
        label2.layer.cornerRadius = 30
        label2.layer.masksToBounds = true
        label2.textAlignment = NSTextAlignment.center
        label2.textColor = UIColor.black
        label2.numberOfLines = 0
        label2.font = UIFont(name: "Arial", size: 14.5)
        label2.font = UIFont.systemFont(ofSize: 20)
        label2.text = """
    Welcome to our kingdom, gentlemen. If we may ask, what is the purpose of all of you coming here?
"""
        return label2
    }()
    
    var speak2: UILabel = {
        let label2 = UILabel()
        label2.frame.origin = CGPoint(x: 0, y: 0)
        label2.frame.size = CGSize(width: 250, height: 200)
        label2.layer.cornerRadius = 30
        label2.layer.masksToBounds = true
        label2.textAlignment = NSTextAlignment.center
        label2.textColor = UIColor.black
        label2.numberOfLines = 0
        label2.font = UIFont(name: "Arial", size: 14.5)
        label2.font = UIFont.systemFont(ofSize: 20)
        label2.text = """
    We got the task to seize the Pagaruyung Kingdom
"""
        return label2
    }()
    
    var speak3: UILabel = {
        let label2 = UILabel()
        label2.frame.origin = CGPoint(x: 0, y: 0)
        label2.frame.size = CGSize(width: 250, height: 200)
        label2.layer.cornerRadius = 30
        label2.layer.masksToBounds = true
        label2.textAlignment = NSTextAlignment.center
        label2.textColor = UIColor.black
        label2.numberOfLines = 0
        label2.font = UIFont(name: "Arial", size: 14.5)
        label2.font = UIFont.systemFont(ofSize: 20)
        label2.text = """
    I see. Alright, how about we replace the war with a buffalo fight. Whoever the buffalo wins, he can rule in this kingdom
"""
        return label2
    }()

    var kotak: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 150)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kotak")
        return foto
    }()
    
    var kotak2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 100)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kotak")
        return foto
    }()
    
    var kotak3: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 150)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kotak")
        return foto
    }()
    
    var raja: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 300)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "raja")
        return foto
    }()
    
    var raja2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 400, height: 400)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "rajasri")
        return foto
    }()
    
    var rumahgadang: UIImageView = {
        let rumah = UIImageView()
        rumah.frame.origin = CGPoint(x: 0, y: 50)
        rumah.frame.size = CGSize(width: 800, height: 500)
        rumah.contentMode = .scaleAspectFill
        
        rumah.image = UIImage(named: "rumah")
        return rumah
    }()
    
    var nextPage4: UIButton = {
        let next4 = UIButton()
        next4.frame.origin = CGPoint(x: 0, y: 0)
        next4.frame.size = CGSize(width: 150, height: 50)
        next4.layer.cornerRadius = 10
        next4.setTitle("Next Story", for: .normal)
        next4.backgroundColor = .systemYellow
        
        return next4
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 400
        view.addSubview(labelWellcome)
        
        nextPage4.center = view.center
        nextPage4.frame.origin.y += 550
        nextPage4.frame.origin.x += 420
        view.addSubview(nextPage4)
        nextPage4.addTarget(self, action: #selector(actionButton4), for: .touchUpInside)
        
        rumahgadang.center = view.center
        rumahgadang.frame.origin.y -= 390
        view.addSubview(rumahgadang)
        
        raja.center = view.center
        raja.frame.origin.x -= 320
        view.addSubview(raja)
        
        raja2.center = view.center
        raja2.frame.origin.x += 200
        view.addSubview(raja2)
        
        kotak.center = view.center
        kotak.frame.origin.y -= 250
        kotak.frame.origin.x -= 180
        view.addSubview(kotak)
        
        speak1.center = view.center
        speak1.frame.origin.y -= 265
        speak1.frame.origin.x -= 180
        view.addSubview(speak1)
        
        kotak2.center = view.center
        kotak2.frame.origin.y -= 250
        kotak2.frame.origin.x += 250
        view.addSubview(kotak2)
        
        speak2.center = view.center
        speak2.frame.origin.y -= 265
        speak2.frame.origin.x += 250
        view.addSubview(speak2)
        
        kotak3.center = view.center
        kotak3.frame.origin.y -= 80
        kotak3.frame.origin.x -= 110
        view.addSubview(kotak3)
        
        speak3.center = view.center
        speak3.frame.origin.y -= 95
        speak3.frame.origin.x -= 110
        view.addSubview(speak3)
    }
    
    @objc func actionButton4() {
        navigationController?.pushViewController(pageFour(), animated: true)
    }
}
