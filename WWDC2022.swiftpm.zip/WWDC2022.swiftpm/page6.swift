//
//  File.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 25/04/22.
//

import UIKit

class pageSix: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 950, height: 400)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
“Manang Kabau! Manang Kabau!” shouted the people of Pagaruyung happily.

The Majapahit Kingdom troops were allowed to return to their kingdom in peace without war. Meanwhile, news of the victory of the buffalo of the Pagaruyung Kingdom became a byword throughout the country. Manang kabau is the language of the local people which means "Winning buffalo". 

"""
        return label
    }()
    
    var menang: UILabel = {
        let label2 = UILabel()
        label2.frame.origin = CGPoint(x: 0, y: 0)
        label2.frame.size = CGSize(width: 300, height: 1500)
        label2.textAlignment = NSTextAlignment.center
        label2.textColor = UIColor.black
        label2.numberOfLines = 0
        label2.font = UIFont(name: "Arial", size: 14.5)
        label2.font = UIFont.systemFont(ofSize: 35)
        label2.text = """
Manang Kabau! Manang Kabau! Manang Kabau! Manang Kabau!
"""
        return label2
    }()
    
    var nextPage7: UIButton = {
        let next7 = UIButton()
        next7.frame.origin = CGPoint(x: 0, y: 0)
        next7.frame.size = CGSize(width: 150, height: 50)
        next7.layer.cornerRadius = 10
        next7.setTitle("Next Story", for: .normal)
        next7.backgroundColor = .systemYellow
        
        return next7
    }()
    var rumahgadang: UIImageView = {
        let rumah = UIImageView()
        rumah.frame.origin = CGPoint(x: 0, y: 50)
        rumah.frame.size = CGSize(width: 800, height: 500)
        rumah.contentMode = .scaleAspectFill
        
        rumah.image = UIImage(named: "rumah")
        return rumah
    }()
    
    var orang: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var orang2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var kotak: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 350, height: 200)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kotak")
        return foto
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 400
        view.addSubview(labelWellcome)
        
        nextPage7.center = view.center
        nextPage7.frame.origin.y += 550
        nextPage7.frame.origin.x += 420
        view.addSubview(nextPage7)
        nextPage7.addTarget(self, action: #selector(actionButton4), for: .touchUpInside)
        
        rumahgadang.center = view.center
        rumahgadang.frame.origin.y -= 380
        view.addSubview(rumahgadang)
        
        //Mark: Image
        
        orang.center = view.center
        orang.frame.origin.y += 20
        orang.frame.origin.x -= 150
        view.addSubview(orang)
        orang2.center = view.center
        orang2.frame.origin.y += 20
        orang2.frame.origin.x += 150
        view.addSubview(orang2)
        
        kotak.center = view.center
        kotak.frame.origin.y -= 200
        kotak.frame.origin.x += 150
        view.addSubview(kotak)
        
        menang.center = view.center
        menang.frame.origin.y -= 230
        menang.frame.origin.x += 150
        view.addSubview(menang)
    }
    
    @objc func actionButton4() {
        navigationController?.pushViewController(pageSeven(), animated: true)
    }
}
