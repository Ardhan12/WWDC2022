//
//  File.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 25/04/22.
//

import UIKit

class pageFour: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 950, height: 380)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
That day arrived. The Majapahit Kingdom brought a very large and strong buffalo to compete with the buffalo from the Pagaruyung Kingdom. The Pagaruyung Kingdom chose a calf that was still suckling with its mother. The calf was deliberately separated from its mother for three days, so that the calf could not suckle from its mother and became thirsty. Then, in the mouth of the calf was installed an iron cone shaped and very pointed.
"""
        return label
    }()
    
    var nextPage5: UIButton = {
        let next5 = UIButton()
        next5.frame.origin = CGPoint(x: 0, y: 0)
        next5.frame.size = CGSize(width: 150, height: 50)
        next5.layer.cornerRadius = 10
        next5.setTitle("Next Story", for: .normal)
        next5.backgroundColor = .systemYellow
        
        return next5
    }()
    
    var kerbau: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kerbaubesar")
        return foto
    }()
   
    var orang: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var orang2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var kerbaukecil: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kerbaukecil")
        return foto
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 380
        view.addSubview(labelWellcome)
        
        nextPage5.center = view.center
        nextPage5.frame.origin.y += 550
        nextPage5.frame.origin.x += 420
        view.addSubview(nextPage5)
        nextPage5.addTarget(self, action: #selector(actionButton4), for: .touchUpInside)
        
        orang.center = view.center
        orang.frame.origin.y -= 400
        orang.frame.origin.x -= 150
        view.addSubview(orang)
        orang2.center = view.center
        orang2.frame.origin.y -= 400
        orang2.frame.origin.x += 150
        view.addSubview(orang2)
        
        //Mark: Image
        kerbau.center = view.center
        kerbau.frame.origin.x -= 250
        kerbau.frame.origin.y -= 200
        view.addSubview(kerbau)
        
        kerbaukecil.center = view.center
        kerbaukecil.frame.origin.x += 250
        kerbaukecil.frame.origin.y += 100
        view.addSubview(kerbaukecil)
    }
    
    @objc func actionButton4() {
        navigationController?.pushViewController(pageFive(), animated: true)
    }
}

