//
//  File.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 23/04/22.
//

import UIKit
import Foundation

class home: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 850, height: 250)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
//        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.white
        label.numberOfLines = 0
        label.font = UIFont(name: "Tapestry", size: 32)
//        label.font = UIFont.systemFont(ofSize: 35)
        label.font = UIFont.boldSystemFont(ofSize: 100)
        label.text = """
The origin of The Minangkabau
"""
        return label
    }()
    
    var rumahgadang: UIImageView = {
        let rumah = UIImageView()
        rumah.frame.origin = CGPoint(x: 0, y: 50)
        rumah.frame.size = CGSize(width: 900, height: 500)
        rumah.contentMode = .scaleAspectFill
        
        rumah.image = UIImage(named: "rumah")
        return rumah
    }()
    
    
    var lastPage: UIButton = {
        let last = UIButton()
        last.frame.origin = CGPoint(x: 0, y: 0)
        last.frame.size = CGSize(width: 150, height: 50)
        last.setTitle("Begin", for: .normal)
        last.layer.cornerRadius = 10
        last.backgroundColor = .systemYellow
        
        return last
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        lastPage.center = view.center
        lastPage.frame.origin.y += 300
        lastPage.addTarget(self, action: #selector(actionButton6), for: .touchUpInside)
        view.addSubview(lastPage)
        
        rumahgadang.center = view.center
        rumahgadang.frame.origin.y -= 330
        view.addSubview(rumahgadang)
        
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 100
        view.addSubview(labelWellcome)
    }
    
    @objc func actionButton6(_ sender: UIButton){
        navigationController?.pushViewController(MainViewController(), animated: true)
    }
    
    
}
