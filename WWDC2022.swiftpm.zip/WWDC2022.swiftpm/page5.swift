//
//  File.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 25/04/22.
//

import UIKit

class pageFive: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 950, height: 380)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
The two buffaloes also competed. The buffalo complaining of the Majapahit Kingdom looks fierce attacking its opponent, the little buffalo. Meanwhile, the calf belonging to the Pagaruyung Kingdom immediately chased the big buffalo to suckle. Apparently, he thought that the big buffalo was his mother. The small snout tried to reach the belly of the opponent's buffalo, so that the stomach of the buffalo of the Majapahit Kingdom was injured. Due to the increasing number of injuries, the buffalo of the Majapahit Kingdom fell down and died.
"""
        return label
    }()
    
    var nextPage6: UIButton = {
        let next6 = UIButton()
        next6.frame.origin = CGPoint(x: 0, y: 0)
        next6.frame.size = CGSize(width: 150, height: 50)
        next6.layer.cornerRadius = 10
        next6.setTitle("Next Story", for: .normal)
        next6.backgroundColor = .systemYellow
        
        return next6
    }()
    
    var orang: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var orang2: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 500, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "orang")
        return foto
    }()
    
    var darah: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 200, height: 200)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "darah")
        return foto
    }()
    
    var kerbau: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kerbaubesar")
        return foto
    }()
   
    var kerbaukecil: UIImageView = {
        let foto = UIImageView()
        foto.frame.origin = CGPoint(x: 0, y: 0)
        foto.frame.size = CGSize(width: 300, height: 250)
        foto.contentMode = .scaleAspectFill
        
        foto.image = UIImage(named: "kerbaukecil")
        return foto
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 380
        view.addSubview(labelWellcome)
        
        nextPage6.center = view.center
        nextPage6.frame.origin.y += 550
        nextPage6.frame.origin.x += 420
        view.addSubview(nextPage6)
        nextPage6.addTarget(self, action: #selector(actionButton4), for: .touchUpInside)
        
        orang.center = view.center
        orang.frame.origin.y -= 400
        orang.frame.origin.x -= 150
        view.addSubview(orang)
        orang2.center = view.center
        orang2.frame.origin.y -= 400
        orang2.frame.origin.x += 150
        view.addSubview(orang2)
        
        kerbau.center = view.center
        kerbau.frame.origin.x -= 100
        kerbau.frame.origin.y -= 50
        view.addSubview(kerbau)
        
        darah.center = view.center
        darah.frame.origin.x -= 100
        darah.frame.origin.y -= 50
        view.addSubview(darah)
        
        kerbaukecil.center = view.center
        kerbaukecil.frame.origin.x += 60
        kerbaukecil.frame.origin.y += 50
        view.addSubview(kerbaukecil)
    }
    
    @objc func actionButton4() {
        navigationController?.pushViewController(pageSix(), animated: true)
    }
}
