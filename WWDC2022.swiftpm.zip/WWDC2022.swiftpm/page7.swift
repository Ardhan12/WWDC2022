//
//  File.swift
//  WWDC2022
//
//  Created by Arief Ramadhan on 25/04/22.
//

import UIKit

class pageSeven: UIViewController {
    
    var labelWellcome: UILabel = {
        let label = UILabel()
        label.frame.origin = CGPoint(x: 0, y: 0)
        label.frame.size = CGSize(width: 850, height: 250)
        label.layer.cornerRadius = 30
        label.layer.masksToBounds = true
        label.backgroundColor = .white
        label.textAlignment = NSTextAlignment.center
        label.textColor = UIColor.black
        label.numberOfLines = 0
        label.font = UIFont(name: "Arial", size: 14.5)
        label.font = UIFont.systemFont(ofSize: 35)
        label.text = """
Finally, the area was known as Manang Kabau which gradually became MINANGKABAU.

THE END
"""
        return label
    }()
    
    var nextLastPage: UIButton = {
        let nextLast = UIButton()
        nextLast.frame.origin = CGPoint(x: 0, y: 0)
        nextLast.frame.size = CGSize(width: 150, height: 50)
        nextLast.layer.cornerRadius = 10
        nextLast.setTitle("Home", for: .normal)
        nextLast.backgroundColor = .systemYellow
        
        return nextLast
    }()
    
    var rumahgadang: UIImageView = {
        let rumah = UIImageView()
        rumah.frame.origin = CGPoint(x: 0, y: 50)
        rumah.frame.size = CGSize(width: 800, height: 500)
        rumah.contentMode = .scaleAspectFill
        
        rumah.image = UIImage(named: "rumah")
        return rumah
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        
        labelWellcome.center = view.center
        labelWellcome.frame.origin.y += 300
        view.addSubview(labelWellcome)
        
        nextLastPage.center = view.center
        nextLastPage.frame.origin.y += 480
        view.addSubview(nextLastPage)
        nextLastPage.addTarget(self, action: #selector(actionButton4), for: .touchUpInside)
        
        rumahgadang.center = view.center
        rumahgadang.frame.origin.y -= 330
        view.addSubview(rumahgadang)
    }
    
    @objc func actionButton4() {
        navigationController?.popToRootViewController(animated: true)
    }
}
